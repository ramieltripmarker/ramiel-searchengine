import { useState, useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import {
  Plane,
  ArrowLeft,
  Plus,
  Trash2,
  TrendingDown,
  Wifi,
  Heart,
  CalendarIcon,
  Save,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const STORAGE_KEY = "tripMarkerFlights";

const PREFERRED_TRANSITS = ["BLR", "MAA", "CMB", "COK", "CCJ", "CNN", "TRV"];
const AVOID_TRANSITS = ["BOM", "DEL"];

const formSchema = z.object({
  date: z.date({ required_error: "Please select a date." }),
  airline: z.string().min(1, "Airline is required"),
  fare: z
    .string()
    .min(1, "Fare is required")
    .refine((v) => !isNaN(Number(v)) && Number(v) > 0, "Must be a positive number"),
  baggage: z.string().min(1, "Baggage allowance is required"),
  flightType: z.enum(["Direct", "1 Stop"]),
  transitAirport: z.string().optional(),
  layoverTime: z.string().optional(),
  totalJourneyTime: z.string().min(1, "Journey time is required"),
  remarks: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export interface SavedFlight {
  id: string;
  date: string;
  airline: string;
  fare: number;
  baggage: string;
  flightType: "Direct" | "1 Stop";
  transitAirport: string;
  layoverTime: string;
  layoverMinutes: number;
  totalJourneyTime: string;
  remarks: string;
}

function parseLayoverMinutes(time: string): number {
  if (!time) return 0;
  const hMatch = time.match(/(\d+)\s*h/i);
  const mMatch = time.match(/(\d+)\s*m/i);
  const hours = hMatch ? parseInt(hMatch[1]) : 0;
  const mins = mMatch ? parseInt(mMatch[1]) : 0;
  return hours * 60 + mins;
}

function loadFlights(): SavedFlight[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveFlights(flights: SavedFlight[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(flights));
  } catch {
    // ignore
  }
}

const isLongLayover = (minutes: number) => minutes >= 360;

function getCheapestDirect(flights: SavedFlight[]): SavedFlight | undefined {
  return [...flights]
    .filter((f) => f.flightType === "Direct")
    .sort((a, b) => a.fare - b.fare)[0];
}

function getCheapestConnecting(flights: SavedFlight[]): SavedFlight | undefined {
  return [...flights]
    .filter((f) => f.flightType === "1 Stop")
    .sort((a, b) => a.fare - b.fare)[0];
}

function getBestFamilyOption(flights: SavedFlight[]): SavedFlight | undefined {
  const connecting = flights.filter((f) => f.flightType === "1 Stop");
  if (connecting.length === 0) return undefined;

  const scored = connecting.map((f) => {
    let score = 0;
    const transit = f.transitAirport.toUpperCase().replace(/\s.*/, "");
    const isPreferred = PREFERRED_TRANSITS.some((p) => transit.includes(p));
    const isAvoided = AVOID_TRANSITS.some((a) => transit.includes(a));
    if (isPreferred) score += 30;
    if (isAvoided) score -= 50;
    if (f.layoverMinutes > 0 && f.layoverMinutes <= 120) score += 20;
    else if (f.layoverMinutes <= 180) score += 15;
    else if (f.layoverMinutes <= 240) score += 10;
    else if (f.layoverMinutes >= 360) score -= 20;
    score -= f.fare / 100;
    return { flight: f, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0]?.flight;
}

const airlineColors: Record<string, string> = {
  "Qatar Airways": "bg-[#5C0632] text-white",
  Emirates: "bg-[#D4A843] text-[#1a1a1a]",
  Etihad: "bg-[#B8872A] text-white",
  "Air India": "bg-[#E8364E] text-white",
  "Air India Express": "bg-[#E8364E] text-white",
  IndiGo: "bg-[#1A1A6E] text-white",
  "Air Arabia": "bg-[#E84040] text-white",
  flydubai: "bg-[#E8A500] text-[#1a1a1a]",
  SpiceJet: "bg-[#E84040] text-white",
};

function AirlineBadge({ airline }: { airline: string }) {
  const initials = airline
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 3)
    .toUpperCase();
  const colorClass =
    Object.entries(airlineColors).find(([key]) =>
      airline.toLowerCase().includes(key.toLowerCase().split(" ")[0])
    )?.[1] ?? "bg-slate-200 text-slate-700";
  return (
    <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${colorClass}`}>
      {initials}
    </span>
  );
}

interface HighlightCardProps {
  icon: React.ReactNode;
  iconBg: string;
  label: string;
  flight: SavedFlight | undefined;
  highlightId: string;
  delay: number;
}

function HighlightCard({ icon, iconBg, label, flight, delay }: HighlightCardProps) {
  if (!flight) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay }}
      >
        <Card className="border-0 shadow-md h-full">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${iconBg} opacity-40`}>
                {icon}
              </div>
              <CardTitle className="text-sm font-semibold text-slate-400 uppercase tracking-wide">
                {label}
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-slate-400 italic">No flights saved yet</p>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  const longLayover = isLongLayover(flight.layoverMinutes);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
    >
      <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 h-full">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${iconBg}`}>
              {icon}
            </div>
            <CardTitle className="text-sm font-semibold text-slate-600 uppercase tracking-wide">
              {label}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AirlineBadge airline={flight.airline} />
              <span className="font-semibold text-slate-800 text-sm">{flight.airline}</span>
            </div>
            <Badge
              variant="outline"
              className={`text-xs ${
                flight.flightType === "Direct"
                  ? "bg-green-50 text-green-700 border-green-200"
                  : "bg-blue-50 text-blue-700 border-blue-200"
              }`}
            >
              {flight.flightType}
            </Badge>
          </div>
          <div className="text-3xl font-bold text-primary">
            QAR {flight.fare.toLocaleString()}
          </div>
          <div className="grid grid-cols-2 gap-1.5 text-xs text-slate-500">
            <span>⏱ {flight.totalJourneyTime}</span>
            <span>🧳 {flight.baggage}</span>
            <span>📅 {flight.date}</span>
            {flight.flightType === "1 Stop" && (
              <span>📍 via {flight.transitAirport}</span>
            )}
          </div>
          {longLayover && (
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-700 rounded-lg px-3 py-2 text-xs font-medium">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
              Long Layover — Not Recommended for Families
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Manager() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [flights, setFlights] = useState<SavedFlight[]>(loadFlights);

  useEffect(() => {
    saveFlights(flights);
  }, [flights]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      airline: "",
      fare: "",
      baggage: "",
      flightType: "Direct",
      transitAirport: "",
      layoverTime: "",
      totalJourneyTime: "",
      remarks: "",
    },
  });

  const flightType = form.watch("flightType");

  const onSubmit = (data: FormValues) => {
    const newFlight: SavedFlight = {
      id: Date.now().toString(),
      date: format(data.date, "dd MMM yyyy"),
      airline: data.airline,
      fare: Number(data.fare),
      baggage: data.baggage,
      flightType: data.flightType,
      transitAirport: data.flightType === "Direct" ? "—" : (data.transitAirport || "—"),
      layoverTime: data.flightType === "Direct" ? "—" : (data.layoverTime || "—"),
      layoverMinutes:
        data.flightType === "Direct" ? 0 : parseLayoverMinutes(data.layoverTime || ""),
      totalJourneyTime: data.totalJourneyTime,
      remarks: data.remarks || "",
    };
    setFlights((prev) => [newFlight, ...prev]);
    form.reset({
      airline: "",
      fare: "",
      baggage: "",
      flightType: "Direct",
      transitAirport: "",
      layoverTime: "",
      totalJourneyTime: "",
      remarks: "",
    });
    toast({ title: "Flight saved!", description: `${newFlight.airline} — QAR ${newFlight.fare}` });
  };

  const deleteFlight = (id: string) => {
    setFlights((prev) => prev.filter((f) => f.id !== id));
    toast({ title: "Flight removed" });
  };

  const cheapestDirect = getCheapestDirect(flights);
  const cheapestConnecting = getCheapestConnecting(flights);
  const bestFamily = getBestFamilyOption(flights);

  const getRowHighlight = (flight: SavedFlight) => {
    if (cheapestDirect?.id === flight.id) return "bg-green-50/60";
    if (cheapestConnecting?.id === flight.id) return "bg-blue-50/60";
    if (bestFamily?.id === flight.id) return "bg-rose-50/60";
    return "";
  };

  const getRowBadge = (flight: SavedFlight) => {
    if (cheapestDirect?.id === flight.id)
      return <Badge className="text-[10px] bg-green-100 text-green-700 hover:bg-green-100 border border-green-200 ml-1">Cheapest Direct</Badge>;
    if (cheapestConnecting?.id === flight.id)
      return <Badge className="text-[10px] bg-blue-100 text-blue-700 hover:bg-blue-100 border border-blue-200 ml-1">Cheapest Connect</Badge>;
    if (bestFamily?.id === flight.id)
      return <Badge className="text-[10px] bg-rose-100 text-rose-700 hover:bg-rose-100 border border-rose-200 ml-1">Best Family</Badge>;
    return null;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-blue-50/30">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 text-slate-600 hover:text-primary"
              onClick={() => setLocation("/")}
              data-testid="btn-back-home"
            >
              <ArrowLeft className="w-4 h-4" />
              Home
            </Button>
            <div className="h-5 w-px bg-slate-200" />
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-primary/10 rounded-md flex items-center justify-center">
                <Plane className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="font-semibold text-slate-800">Flight Results Manager</span>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-slate-400" />
            <span className="text-sm text-slate-500">
              {flights.length} flight{flights.length !== 1 ? "s" : ""} saved
            </span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">

        {/* Page heading */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <h1 className="text-2xl font-bold text-slate-800">Enter Flight Results</h1>
          <p className="text-slate-500 mt-1 text-sm">
            Manually log flight options. The best picks are highlighted automatically.
          </p>
        </motion.div>

        {/* Entry form */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.05 }}
        >
          <Card className="border-0 shadow-lg">
            <CardHeader className="pb-4 border-b border-slate-100">
              <CardTitle className="text-base font-semibold text-slate-700 flex items-center gap-2">
                <Plus className="w-4 h-4 text-primary" />
                Add New Flight
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <Form {...form}>
                <form
                  onSubmit={form.handleSubmit(onSubmit)}
                  className="space-y-5"
                  data-testid="form-add-flight"
                >
                  {/* Row 1: Date + Airline + Fare + Baggage */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Date */}
                    <FormField
                      control={form.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  type="button"
                                  variant="outline"
                                  className={cn(
                                    "w-full h-10 pl-3 text-left font-medium rounded-xl bg-slate-50 border-slate-200 hover:bg-slate-100 text-sm",
                                    !field.value && "text-muted-foreground"
                                  )}
                                  data-testid="btn-flight-date"
                                >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground/60" />
                                  {field.value ? format(field.value, "dd MMM yyyy") : "Select date"}
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0 rounded-2xl" align="start">
                              <Calendar
                                mode="single"
                                selected={field.value}
                                onSelect={field.onChange}
                                initialFocus
                                className="p-3"
                              />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Airline */}
                    <FormField
                      control={form.control}
                      name="airline"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Airline</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="e.g. Qatar Airways"
                              className="h-10 rounded-xl bg-slate-50 border-slate-200 text-sm"
                              data-testid="input-airline"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Fare */}
                    <FormField
                      control={form.control}
                      name="fare"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Fare (QAR)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              placeholder="e.g. 1250"
                              className="h-10 rounded-xl bg-slate-50 border-slate-200 text-sm"
                              data-testid="input-fare"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Baggage */}
                    <FormField
                      control={form.control}
                      name="baggage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Baggage</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="e.g. 30 kg"
                              className="h-10 rounded-xl bg-slate-50 border-slate-200 text-sm"
                              data-testid="input-baggage"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Row 2: Flight Type + Transit Airport + Layover + Total Journey */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {/* Flight Type */}
                    <FormField
                      control={form.control}
                      name="flightType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Flight Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger
                                className="h-10 rounded-xl bg-slate-50 border-slate-200 text-sm"
                                data-testid="select-flight-type"
                              >
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Direct">Direct</SelectItem>
                              <SelectItem value="1 Stop">1 Stop</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Transit Airport */}
                    <FormField
                      control={form.control}
                      name="transitAirport"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Transit Airport</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="e.g. Dubai (DXB)"
                              className={cn(
                                "h-10 rounded-xl bg-slate-50 border-slate-200 text-sm",
                                flightType === "Direct" && "opacity-40 cursor-not-allowed"
                              )}
                              disabled={flightType === "Direct"}
                              data-testid="input-transit-airport"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Layover Time */}
                    <FormField
                      control={form.control}
                      name="layoverTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Layover Time</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="e.g. 2h 30m"
                              className={cn(
                                "h-10 rounded-xl bg-slate-50 border-slate-200 text-sm",
                                flightType === "Direct" && "opacity-40 cursor-not-allowed"
                              )}
                              disabled={flightType === "Direct"}
                              data-testid="input-layover-time"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Total Journey Time */}
                    <FormField
                      control={form.control}
                      name="totalJourneyTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Total Journey</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="e.g. 8h 15m"
                              className="h-10 rounded-xl bg-slate-50 border-slate-200 text-sm"
                              data-testid="input-total-journey"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Row 3: Remarks + Submit */}
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 items-end">
                    <FormField
                      control={form.control}
                      name="remarks"
                      render={({ field }) => (
                        <FormItem className="lg:col-span-3">
                          <FormLabel className="text-xs uppercase tracking-wider text-muted-foreground">Remarks</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Any notes about this flight..."
                              className="rounded-xl bg-slate-50 border-slate-200 text-sm resize-none h-10 py-2"
                              data-testid="input-remarks"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      className="h-10 rounded-xl font-semibold shadow-md hover:shadow-lg transition-all"
                      data-testid="btn-save-flight"
                    >
                      <Save className="mr-2 h-4 w-4" />
                      Save Flight
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </motion.div>

        {/* Highlight cards — only shown when there are flights */}
        {flights.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <HighlightCard
              icon={<TrendingDown className="w-5 h-5 text-white" />}
              iconBg="bg-green-500"
              label="Cheapest Direct Flight"
              flight={cheapestDirect}
              highlightId="cheapest-direct"
              delay={0.1}
            />
            <HighlightCard
              icon={<Wifi className="w-5 h-5 text-white" />}
              iconBg="bg-blue-500"
              label="Cheapest Connecting Flight"
              flight={cheapestConnecting}
              highlightId="cheapest-connecting"
              delay={0.15}
            />
            <HighlightCard
              icon={<Heart className="w-5 h-5 text-white" />}
              iconBg="bg-rose-500"
              label="Best Family Option"
              flight={bestFamily}
              highlightId="best-family"
              delay={0.2}
            />
          </div>
        )}

        {/* Saved flights table */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.25 }}
        >
          <Card className="border-0 shadow-lg overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-blue-50 border-b border-slate-100 py-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold text-slate-700 flex items-center gap-2">
                  <Plane className="w-4 h-4 text-primary" />
                  Saved Flights
                  {flights.length > 0 && (
                    <Badge variant="secondary" className="ml-1 text-xs">
                      {flights.length}
                    </Badge>
                  )}
                </CardTitle>
                {flights.length > 0 && (
                  <div className="flex items-center gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-green-200 border border-green-400" />
                      Cheapest Direct
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-blue-200 border border-blue-400" />
                      Cheapest Connect
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block w-2.5 h-2.5 rounded-full bg-rose-200 border border-rose-400" />
                      Best Family
                    </span>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {flights.length === 0 ? (
                <div className="py-16 text-center text-slate-400">
                  <Plane className="w-10 h-10 mx-auto mb-3 opacity-30" />
                  <p className="font-medium">No flights saved yet</p>
                  <p className="text-sm mt-1">Fill in the form above and click "Save Flight"</p>
                </div>
              ) : (
                <Table data-testid="table-saved-flights">
                  <TableHeader>
                    <TableRow className="bg-slate-50 hover:bg-slate-50">
                      {[
                        "Date",
                        "Airline",
                        "Fare (QAR)",
                        "Baggage",
                        "Flight Type",
                        "Transit Airport",
                        "Layover Time",
                        "Total Journey",
                        "Remarks",
                        "",
                      ].map((h) => (
                        <TableHead
                          key={h}
                          className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap text-xs uppercase tracking-wider"
                        >
                          {h}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {flights.map((flight, index) => {
                      const longLayover = isLongLayover(flight.layoverMinutes);
                      const rowHighlight = getRowHighlight(flight);
                      const rowBadge = getRowBadge(flight);

                      return (
                        <motion.tr
                          key={flight.id}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.25, delay: 0.03 * index }}
                          className={`border-b last:border-0 transition-colors hover:brightness-95 ${rowHighlight}`}
                          data-testid={`row-saved-flight-${flight.id}`}
                        >
                          <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                            {flight.date}
                          </TableCell>
                          <TableCell className="px-4 py-3">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <AirlineBadge airline={flight.airline} />
                              <span className="text-sm font-medium text-slate-800 whitespace-nowrap">
                                {flight.airline}
                              </span>
                              {rowBadge}
                            </div>
                          </TableCell>
                          <TableCell className="px-4 py-3 text-right">
                            <span className="text-sm font-bold text-primary">
                              {flight.fare.toLocaleString()}
                            </span>
                          </TableCell>
                          <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                            {flight.baggage}
                          </TableCell>
                          <TableCell className="px-4 py-3">
                            <Badge
                              variant="outline"
                              className={`text-xs whitespace-nowrap ${
                                flight.flightType === "Direct"
                                  ? "bg-green-50 text-green-700 border-green-200"
                                  : "bg-blue-50 text-blue-700 border-blue-200"
                              }`}
                            >
                              {flight.flightType}
                            </Badge>
                          </TableCell>
                          <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                            {flight.transitAirport}
                          </TableCell>
                          <TableCell className="px-4 py-3 whitespace-nowrap">
                            {longLayover ? (
                              <div className="flex items-center gap-1.5">
                                <span className="text-sm text-amber-700 font-medium">{flight.layoverTime}</span>
                                <span
                                  className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 border border-amber-300 rounded-md px-2 py-0.5 text-xs font-semibold"
                                  data-testid={`warning-layover-${flight.id}`}
                                >
                                  <AlertTriangle className="w-3 h-3" />
                                  Long Layover
                                </span>
                              </div>
                            ) : (
                              <span className="text-sm text-slate-600">{flight.layoverTime}</span>
                            )}
                          </TableCell>
                          <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                            {flight.totalJourneyTime}
                          </TableCell>
                          <TableCell className="px-4 py-3 text-sm text-slate-500 min-w-[140px]">
                            {flight.remarks || "—"}
                          </TableCell>
                          <TableCell className="px-4 py-3">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              onClick={() => deleteFlight(flight.id)}
                              data-testid={`btn-delete-flight-${flight.id}`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </TableCell>
                        </motion.tr>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <p className="text-center text-xs text-slate-400 pb-4">
          Flights are saved in your browser. They persist across sessions on this device.
        </p>
      </div>
    </div>
  );
}
