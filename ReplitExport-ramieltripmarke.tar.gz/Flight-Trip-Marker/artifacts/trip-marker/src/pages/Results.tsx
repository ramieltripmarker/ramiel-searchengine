import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  Plane,
  ArrowLeft,
  TrendingDown,
  Wifi,
  Star,
  AlertTriangle,
  Clock,
  Luggage,
  MapPin,
  ClipboardList,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface FlightResult {
  id: number;
  date: string;
  airline: string;
  airlineCode: string;
  fare: number;
  baggage: string;
  flightType: "Direct" | "1 Stop";
  transitAirport: string;
  layoverTime: string;
  layoverMinutes: number;
  totalJourneyTime: string;
  remarks: string;
}

const SAMPLE_FLIGHTS: FlightResult[] = [
  {
    id: 1,
    date: "25 Jun 2026",
    airline: "Qatar Airways",
    airlineCode: "QR",
    fare: 1250,
    baggage: "30 kg",
    flightType: "Direct",
    transitAirport: "—",
    layoverTime: "—",
    layoverMinutes: 0,
    totalJourneyTime: "4h 15m",
    remarks: "Best in-flight service",
  },
  {
    id: 2,
    date: "25 Jun 2026",
    airline: "Air India Express",
    airlineCode: "IX",
    fare: 890,
    baggage: "15 kg",
    flightType: "Direct",
    transitAirport: "—",
    layoverTime: "—",
    layoverMinutes: 0,
    totalJourneyTime: "4h 30m",
    remarks: "Budget direct option",
  },
  {
    id: 3,
    date: "25 Jun 2026",
    airline: "IndiGo",
    airlineCode: "6E",
    fare: 750,
    baggage: "15 kg",
    flightType: "1 Stop",
    transitAirport: "Mumbai (BOM)",
    layoverTime: "2h 30m",
    layoverMinutes: 150,
    totalJourneyTime: "9h 00m",
    remarks: "Economy class",
  },
  {
    id: 4,
    date: "25 Jun 2026",
    airline: "Air Arabia",
    airlineCode: "G9",
    fare: 680,
    baggage: "20 kg",
    flightType: "1 Stop",
    transitAirport: "Sharjah (SHJ)",
    layoverTime: "3h 45m",
    layoverMinutes: 225,
    totalJourneyTime: "10h 30m",
    remarks: "Good value for money",
  },
  {
    id: 5,
    date: "26 Jun 2026",
    airline: "Emirates",
    airlineCode: "EK",
    fare: 1450,
    baggage: "35 kg",
    flightType: "1 Stop",
    transitAirport: "Dubai (DXB)",
    layoverTime: "2h 00m",
    layoverMinutes: 120,
    totalJourneyTime: "8h 15m",
    remarks: "Premium comfort & lounge",
  },
  {
    id: 6,
    date: "26 Jun 2026",
    airline: "Etihad Airways",
    airlineCode: "EY",
    fare: 1380,
    baggage: "30 kg",
    flightType: "1 Stop",
    transitAirport: "Abu Dhabi (AUH)",
    layoverTime: "2h 30m",
    layoverMinutes: 150,
    totalJourneyTime: "8h 45m",
    remarks: "Comfortable seating",
  },
  {
    id: 7,
    date: "26 Jun 2026",
    airline: "flydubai",
    airlineCode: "FZ",
    fare: 820,
    baggage: "20 kg",
    flightType: "1 Stop",
    transitAirport: "Dubai (DXB)",
    layoverTime: "7h 30m",
    layoverMinutes: 450,
    totalJourneyTime: "14h 00m",
    remarks: "Long layover at DXB",
  },
  {
    id: 8,
    date: "27 Jun 2026",
    airline: "Qatar Airways",
    airlineCode: "QR",
    fare: 1180,
    baggage: "30 kg",
    flightType: "Direct",
    transitAirport: "—",
    layoverTime: "—",
    layoverMinutes: 0,
    totalJourneyTime: "4h 15m",
    remarks: "Great service, slight discount",
  },
  {
    id: 9,
    date: "27 Jun 2026",
    airline: "SpiceJet",
    airlineCode: "SG",
    fare: 710,
    baggage: "15 kg",
    flightType: "1 Stop",
    transitAirport: "Delhi (DEL)",
    layoverTime: "8h 00m",
    layoverMinutes: 480,
    totalJourneyTime: "15h 30m",
    remarks: "Overnight layover at DEL",
  },
  {
    id: 10,
    date: "28 Jun 2026",
    airline: "Air India",
    airlineCode: "AI",
    fare: 1050,
    baggage: "25 kg",
    flightType: "1 Stop",
    transitAirport: "Mumbai (BOM)",
    layoverTime: "1h 30m",
    layoverMinutes: 90,
    totalJourneyTime: "8h 00m",
    remarks: "Reasonable connection time",
  },
];

const isLongLayover = (minutes: number) => minutes >= 360;

function getCheapestDirect(): FlightResult | undefined {
  return SAMPLE_FLIGHTS.filter((f) => f.flightType === "Direct").sort(
    (a, b) => a.fare - b.fare
  )[0];
}

function getCheapestConnecting(): FlightResult | undefined {
  return SAMPLE_FLIGHTS.filter((f) => f.flightType === "1 Stop").sort(
    (a, b) => a.fare - b.fare
  )[0];
}

function getMostComfortable(): FlightResult | undefined {
  return SAMPLE_FLIGHTS.filter((f) => f.flightType === "1 Stop")
    .filter((f) => !isLongLayover(f.layoverMinutes))
    .sort((a, b) => {
      const baggageA = parseInt(a.baggage);
      const baggageB = parseInt(b.baggage);
      if (baggageB !== baggageA) return baggageB - baggageA;
      return a.fare - b.fare;
    })[0];
}

const airlineColors: Record<string, string> = {
  QR: "bg-[#5C0632] text-white",
  EK: "bg-[#D4A843] text-[#1a1a1a]",
  EY: "bg-[#B8872A] text-white",
  IX: "bg-[#E8364E] text-white",
  "6E": "bg-[#1A1A6E] text-white",
  G9: "bg-[#E84040] text-white",
  FZ: "bg-[#E8A500] text-[#1a1a1a]",
  AI: "bg-[#E8364E] text-white",
  SG: "bg-[#E84040] text-white",
};

function HighlightCard({
  icon,
  iconBg,
  label,
  flight,
  delay,
}: {
  icon: React.ReactNode;
  iconBg: string;
  label: string;
  flight: FlightResult | undefined;
  delay: number;
}) {
  if (!flight) return null;
  const longLayover = isLongLayover(flight.layoverMinutes);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <Card
        className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300 h-full"
        data-testid={`card-highlight-${label.toLowerCase().replace(/\s+/g, "-")}`}
      >
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${iconBg}`}>
              {icon}
            </div>
            <CardTitle className="text-sm font-semibold text-slate-600 uppercase tracking-wide">
              {label}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                  airlineColors[flight.airlineCode] ?? "bg-slate-100 text-slate-700"
                }`}
              >
                {flight.airlineCode}
              </span>
              <span className="font-semibold text-slate-800">{flight.airline}</span>
            </div>
            <Badge variant="outline" className="text-xs">
              {flight.flightType}
            </Badge>
          </div>

          <div className="text-3xl font-bold text-primary">
            QAR {flight.fare.toLocaleString()}
          </div>

          <div className="grid grid-cols-2 gap-2 text-sm text-slate-600">
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              {flight.totalJourneyTime}
            </div>
            <div className="flex items-center gap-1.5">
              <Luggage className="w-3.5 h-3.5 text-slate-400" />
              {flight.baggage}
            </div>
            {flight.flightType === "1 Stop" && (
              <div className="flex items-center gap-1.5 col-span-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                via {flight.transitAirport}
              </div>
            )}
          </div>

          {longLayover && (
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-700 rounded-lg px-3 py-2 text-xs font-medium">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              Long Layover - Not Recommended for Families
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function Results() {
  const [, setLocation] = useLocation();

  const cheapestDirect = getCheapestDirect();
  const cheapestConnecting = getCheapestConnecting();
  const mostComfortable = getMostComfortable();

  const searchParams = (() => {
    try {
      const raw = sessionStorage.getItem("tripMarkerSearch");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  })();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-blue-50/30">
      {/* Header bar */}
      <div className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 text-slate-600 hover:text-primary"
              onClick={() => setLocation("/")}
              data-testid="btn-back-to-search"
            >
              <ArrowLeft className="w-4 h-4" />
              Modify Search
            </Button>
            <div className="h-5 w-px bg-slate-200" />
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Plane className="w-4 h-4 text-primary" />
              <span className="font-semibold text-slate-700">
                {searchParams?.from || "Doha (DOH)"}
              </span>
              <span>→</span>
              <span className="font-semibold text-slate-700">
                {searchParams?.to || "Kochi (COK)"}
              </span>
              {searchParams?.departureDate && (
                <>
                  <span className="text-slate-300">·</span>
                  <span>{new Date(searchParams.departureDate).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}</span>
                </>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="gap-2 text-slate-600 border-slate-200 hover:text-primary hover:border-primary"
              onClick={() => setLocation("/manager")}
              data-testid="btn-open-manager"
            >
              <ClipboardList className="w-4 h-4" />
              <span className="hidden sm:inline">Flight Manager</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">

        {/* Page title */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <h1 className="text-2xl font-bold text-slate-800">
            Flight Search Results
          </h1>
          <p className="text-slate-500 mt-1 text-sm">
            {SAMPLE_FLIGHTS.length} flights found from Qatar to Kerala · Prices in QAR · Sample data
          </p>
        </motion.div>

        {/* Highlight cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <HighlightCard
            icon={<TrendingDown className="w-5 h-5 text-white" />}
            iconBg="bg-green-500"
            label="Cheapest Direct Flight"
            flight={cheapestDirect}
            delay={0.1}
          />
          <HighlightCard
            icon={<Wifi className="w-5 h-5 text-white" />}
            iconBg="bg-blue-500"
            label="Cheapest Connecting Flight"
            flight={cheapestConnecting}
            delay={0.2}
          />
          <HighlightCard
            icon={<Star className="w-5 h-5 text-white" />}
            iconBg="bg-violet-500"
            label="Most Comfortable Connection"
            flight={mostComfortable}
            delay={0.3}
          />
        </div>

        {/* Flight results table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card className="border-0 shadow-lg overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-primary/5 to-blue-50 border-b border-slate-100 py-4">
              <CardTitle className="text-base font-semibold text-slate-700 flex items-center gap-2">
                <Plane className="w-4 h-4 text-primary" />
                All Available Flights
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table data-testid="table-flight-results">
                <TableHeader>
                  <TableRow className="bg-slate-50 hover:bg-slate-50">
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">Date</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">Airline</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap text-right">Fare (QAR)</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">Baggage</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">Flight Type</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">Transit Airport</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">Layover Time</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700 whitespace-nowrap">Total Journey</TableHead>
                    <TableHead className="px-4 py-3 font-semibold text-slate-700">Remarks</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {SAMPLE_FLIGHTS.map((flight, index) => {
                    const longLayover = isLongLayover(flight.layoverMinutes);
                    return (
                      <motion.tr
                        key={flight.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3, delay: 0.05 * index }}
                        className={`border-b last:border-0 transition-colors hover:bg-blue-50/40 ${
                          longLayover ? "bg-amber-50/50" : ""
                        }`}
                        data-testid={`row-flight-${flight.id}`}
                      >
                        <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                          {flight.date}
                        </TableCell>
                        <TableCell className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                                airlineColors[flight.airlineCode] ??
                                "bg-slate-100 text-slate-700"
                              }`}
                            >
                              {flight.airlineCode}
                            </span>
                            <span className="text-sm font-medium text-slate-800 whitespace-nowrap">
                              {flight.airline}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="px-4 py-3 text-right">
                          <span className="text-sm font-bold text-primary">
                            {flight.fare.toLocaleString()}
                          </span>
                        </TableCell>
                        <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                          {flight.baggage}
                        </TableCell>
                        <TableCell className="px-4 py-3">
                          <Badge
                            variant={flight.flightType === "Direct" ? "default" : "secondary"}
                            className={`text-xs whitespace-nowrap ${
                              flight.flightType === "Direct"
                                ? "bg-green-100 text-green-700 hover:bg-green-100 border-green-200"
                                : "bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200"
                            }`}
                          >
                            {flight.flightType}
                          </Badge>
                        </TableCell>
                        <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                          {flight.transitAirport}
                        </TableCell>
                        <TableCell className="px-4 py-3 whitespace-nowrap">
                          {longLayover ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm text-amber-700 font-medium">{flight.layoverTime}</span>
                              <span
                                className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 border border-amber-300 rounded-md px-2 py-0.5 text-xs font-semibold"
                                data-testid={`warning-long-layover-${flight.id}`}
                              >
                                <AlertTriangle className="w-3 h-3" />
                                Long Layover - Not Recommended for Families
                              </span>
                            </div>
                          ) : (
                            <span className="text-sm text-slate-600">{flight.layoverTime}</span>
                          )}
                        </TableCell>
                        <TableCell className="px-4 py-3 text-sm text-slate-600 whitespace-nowrap">
                          {flight.totalJourneyTime}
                        </TableCell>
                        <TableCell className="px-4 py-3 text-sm text-slate-500 min-w-[160px]">
                          {flight.remarks}
                        </TableCell>
                      </motion.tr>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </motion.div>

        <p className="text-center text-xs text-slate-400 pb-4">
          * Sample data only. Prices and availability are not real. Contact your travel agent for live fares.
        </p>
      </div>
    </div>
  );
}
