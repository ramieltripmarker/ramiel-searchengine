import { useState, useEffect, useRef } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import {
  Plane, Users, Calendar as CalendarIcon, Shield, MessageCircle,
  Minus, Plus, X, Trash2, Pencil, Copy, ExternalLink, CheckCircle2,
  TrendingDown, Wifi, Heart, Zap, AlertTriangle, Save, Clock,
  ClipboardList, UserCircle, Phone, ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

// ─── Storage keys ────────────────────────────────────────────────────────────
const ENQUIRY_KEY = "ramielEnquiry";
const RULES_KEY   = "ramielSearchRules";
const FLIGHTS_KEY = "tripMarkerFlights";

// ─── Constants ────────────────────────────────────────────────────────────────
const DEFAULT_PREFERRED = ["BLR", "MAA", "CMB", "COK", "CCJ", "CNN", "TRV"];
const DEFAULT_AVOID     = ["BOM", "DEL"];

// ─── Types ────────────────────────────────────────────────────────────────────
interface SavedFlight {
  id: string;
  date: string;
  airline: string;
  fare: number;
  baggage: string;
  flightType: "Direct" | "1 Stop";
  transitAirport: string;
  layoverTime: string;
  layoverMinutes: number;
  totalJourneyTime: string;
  journeyMinutes: number;
  remarks: string;
}

interface SearchRules {
  maxLayoverHours: number;
  preferred: string[];
  avoid: string[];
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function parseMinutes(time: string): number {
  if (!time || time === "—") return 0;
  const h = time.match(/(\d+)\s*h/i);
  const m = time.match(/(\d+)\s*m/i);
  return (h ? parseInt(h[1]) : 0) * 60 + (m ? parseInt(m[1]) : 0);
}

function loadJson<T>(key: string, fallback: T): T {
  try { const r = localStorage.getItem(key); return r ? JSON.parse(r) : fallback; }
  catch { return fallback; }
}

function saveJson(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* noop */ }
}

function getCheapestDirect(flights: SavedFlight[]) {
  return [...flights].filter(f => f.flightType === "Direct").sort((a,b) => a.fare - b.fare)[0];
}
function getCheapestConnecting(flights: SavedFlight[]) {
  return [...flights].filter(f => f.flightType === "1 Stop").sort((a,b) => a.fare - b.fare)[0];
}
function getBestFamily(flights: SavedFlight[], preferred: string[], avoid: string[]) {
  const connecting = flights.filter(f => f.flightType === "1 Stop");
  if (!connecting.length) return undefined;
  return connecting.map(f => {
    const t = f.transitAirport.toUpperCase();
    const isPreferred = preferred.some(p => t.includes(p));
    const isAvoided   = avoid.some(a => t.includes(a));
    let score = 0;
    if (isPreferred) score += 30;
    if (isAvoided)   score -= 50;
    if (f.layoverMinutes > 0 && f.layoverMinutes <= 120) score += 20;
    else if (f.layoverMinutes <= 180) score += 15;
    else if (f.layoverMinutes <= 240) score += 10;
    else if (f.layoverMinutes >= 360) score -= 20;
    score -= f.fare / 100;
    return { f, score };
  }).sort((a,b) => b.score - a.score)[0]?.f;
}
function getFastest(flights: SavedFlight[]) {
  if (!flights.length) return undefined;
  return [...flights].sort((a,b) => a.journeyMinutes - b.journeyMinutes)[0];
}

// ─── Shared sub-components ───────────────────────────────────────────────────
function DatePicker({ label, value, onChange, testId, minDate }: {
  label: string; value: Date | undefined;
  onChange: (d: Date | undefined) => void; testId: string; minDate?: Date;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">{label}</span>
      <Popover>
        <PopoverTrigger asChild>
          <Button type="button" variant="outline"
            className={cn("w-full h-10 pl-3 text-left text-sm font-medium rounded-lg bg-slate-50 border-slate-200 hover:bg-slate-100", !value && "text-muted-foreground")}
            data-testid={testId}>
            <CalendarIcon className="mr-2 h-4 w-4 text-slate-400" />
            {value ? format(value, "dd MMM yyyy") : "Select date"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0 rounded-xl" align="start">
          <Calendar mode="single" selected={value} onSelect={onChange}
            disabled={d => { const min = minDate ?? new Date(new Date().setHours(0,0,0,0)); return d < min; }}
            initialFocus className="p-3" />
        </PopoverContent>
      </Popover>
    </div>
  );
}

function Stepper({ label, sub, value, onDecrement, onIncrement, min = 0, testId }: {
  label: string; sub: string; value: number;
  onDecrement: () => void; onIncrement: () => void; min?: number; testId: string;
}) {
  return (
    <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 border border-slate-100">
      <div>
        <p className="text-sm font-medium text-slate-700">{label}</p>
        <p className="text-xs text-slate-400">{sub}</p>
      </div>
      <div className="flex items-center gap-2.5">
        <Button type="button" variant="outline" size="icon"
          className="h-7 w-7 rounded-full border-slate-200 bg-white"
          onClick={onDecrement} disabled={value <= min} data-testid={`${testId}-minus`}>
          <Minus className="h-3 w-3" />
        </Button>
        <span className="w-5 text-center font-semibold text-sm" data-testid={testId}>{value}</span>
        <Button type="button" variant="outline" size="icon"
          className="h-7 w-7 rounded-full border-slate-200 bg-white"
          onClick={onIncrement} data-testid={`${testId}-plus`}>
          <Plus className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}

function AirportTags({ label, tags, onChange, colorClass, testId }: {
  label: string; tags: string[]; onChange: (t: string[]) => void; colorClass: string; testId: string;
}) {
  const [input, setInput] = useState("");
  const ref = useRef<HTMLInputElement>(null);
  const safe = tags ?? [];
  const add = (raw: string) => {
    const code = raw.trim().toUpperCase();
    if (code.length >= 2 && code.length <= 4 && !safe.includes(code)) onChange([...safe, code]);
    setInput("");
  };
  const remove = (code: string) => onChange(safe.filter(t => t !== code));
  return (
    <div className="space-y-1.5" data-testid={testId}>
      <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{label}</p>
      <div className="flex flex-wrap gap-1.5 p-2.5 rounded-lg bg-slate-50 border border-slate-200 min-h-[44px] cursor-text" onClick={() => ref.current?.focus()}>
        {safe.map(code => (
          <Badge key={code} className={`gap-1 text-xs font-semibold pr-1 ${colorClass}`}>
            {code}
            <button type="button" onClick={e => { e.stopPropagation(); remove(code); }} className="hover:opacity-60">
              <X className="w-3 h-3" />
            </button>
          </Badge>
        ))}
        <input ref={ref} value={input} onChange={e => setInput(e.target.value.toUpperCase())}
          onKeyDown={e => {
            if (["Enter",","," "].includes(e.key)) { e.preventDefault(); add(input); }
            if (e.key === "Backspace" && !input && safe.length) onChange(safe.slice(0,-1));
          }}
          onBlur={() => { if (input) add(input); }}
          placeholder={safe.length ? "Add…" : "Type code + Enter"}
          maxLength={4} className="bg-transparent outline-none text-xs font-mono placeholder:text-slate-400 w-20 flex-shrink-0" />
      </div>
    </div>
  );
}

function FlightHighlightCard({ icon, iconBg, label, flight, delay }: {
  icon: React.ReactNode; iconBg: string; label: string; flight: SavedFlight | undefined; delay: number;
}) {
  const longLayover = flight ? flight.layoverMinutes >= 360 : false;
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay }}>
      <Card className="border border-slate-200 shadow-sm h-full hover:shadow-md transition-shadow">
        <CardHeader className="pb-2 pt-4 px-4">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${iconBg}`}>{icon}</div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wide">{label}</p>
          </div>
        </CardHeader>
        <CardContent className="px-4 pb-4">
          {!flight ? (
            <p className="text-sm text-slate-400 italic">No flights entered yet</p>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-800 text-sm">{flight.airline}</span>
                <Badge variant="outline" className={`text-[10px] ${flight.flightType === "Direct" ? "border-green-300 text-green-700 bg-green-50" : "border-blue-300 text-blue-700 bg-blue-50"}`}>
                  {flight.flightType}
                </Badge>
              </div>
              <p className="text-2xl font-bold text-primary">QAR {flight.fare.toLocaleString()}</p>
              <div className="grid grid-cols-2 gap-1 text-xs text-slate-500">
                <span>⏱ {flight.totalJourneyTime}</span>
                <span>🧳 {flight.baggage}</span>
                <span>📅 {flight.date}</span>
                {flight.flightType === "1 Stop" && <span className="col-span-2">📍 {flight.transitAirport}</span>}
              </div>
              {longLayover && (
                <div className="flex items-center gap-1.5 bg-amber-50 border border-amber-200 text-amber-700 rounded-md px-2.5 py-1.5 text-xs font-medium">
                  <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                  Long Layover — Not Recommended for Families
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ─── Flight Form (shared Add/Edit dialog) ────────────────────────────────────
const flightSchema = z.object({
  date: z.date({ required_error: "Date required" }),
  airline: z.string().min(1, "Required"),
  fare: z.string().min(1, "Required").refine(v => !isNaN(Number(v)) && Number(v) > 0, "Positive number"),
  baggage: z.string().min(1, "Required"),
  flightType: z.enum(["Direct", "1 Stop"]),
  transitAirport: z.string().optional(),
  layoverTime: z.string().optional(),
  totalJourneyTime: z.string().min(1, "Required"),
  remarks: z.string().optional(),
});
type FlightFormValues = z.infer<typeof flightSchema>;

function FlightFormDialog({ open, onClose, editFlight, onSave }: {
  open: boolean; onClose: () => void;
  editFlight: SavedFlight | null;
  onSave: (flight: SavedFlight) => void;
}) {
  const { toast } = useToast();
  const form = useForm<FlightFormValues>({
    resolver: zodResolver(flightSchema),
    defaultValues: { airline: "", fare: "", baggage: "", flightType: "Direct", transitAirport: "", layoverTime: "", totalJourneyTime: "", remarks: "" },
  });
  const flightType = form.watch("flightType");

  useEffect(() => {
    if (open) {
      if (editFlight) {
        form.reset({
          date: new Date(editFlight.date),
          airline: editFlight.airline,
          fare: String(editFlight.fare),
          baggage: editFlight.baggage,
          flightType: editFlight.flightType,
          transitAirport: editFlight.transitAirport === "—" ? "" : editFlight.transitAirport,
          layoverTime: editFlight.layoverTime === "—" ? "" : editFlight.layoverTime,
          totalJourneyTime: editFlight.totalJourneyTime,
          remarks: editFlight.remarks,
        });
      } else {
        form.reset({ airline: "", fare: "", baggage: "", flightType: "Direct", transitAirport: "", layoverTime: "", totalJourneyTime: "", remarks: "" });
      }
    }
  }, [open, editFlight]);

  const onSubmit = (data: FlightFormValues) => {
    const layoverMins = data.flightType === "Direct" ? 0 : parseMinutes(data.layoverTime ?? "");
    const journeyMins = parseMinutes(data.totalJourneyTime);
    const saved: SavedFlight = {
      id: editFlight?.id ?? Date.now().toString(),
      date: format(data.date, "dd MMM yyyy"),
      airline: data.airline,
      fare: Number(data.fare),
      baggage: data.baggage,
      flightType: data.flightType,
      transitAirport: data.flightType === "Direct" ? "—" : (data.transitAirport || "—"),
      layoverTime: data.flightType === "Direct" ? "—" : (data.layoverTime || "—"),
      layoverMinutes: layoverMins,
      totalJourneyTime: data.totalJourneyTime,
      journeyMinutes: journeyMins,
      remarks: data.remarks ?? "",
    };
    onSave(saved);
    toast({ title: editFlight ? "Flight updated" : "Flight saved", description: `${saved.airline} — QAR ${saved.fare}` });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={v => { if (!v) onClose(); }}>
      <DialogContent className="max-w-2xl rounded-2xl">
        <DialogHeader>
          <DialogTitle>{editFlight ? "Edit Flight" : "Add New Flight"}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <FormField control={form.control} name="date" render={({ field }) => (
                <FormItem className="col-span-2 sm:col-span-1 flex flex-col">
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Date</FormLabel>
                  <FormControl>
                    <DatePicker label="" value={field.value} onChange={field.onChange} testId="dlg-date" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="airline" render={({ field }) => (
                <FormItem className="col-span-2 sm:col-span-1">
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Airline</FormLabel>
                  <FormControl><Input placeholder="e.g. Qatar Airways" className="h-10 rounded-lg bg-slate-50 border-slate-200 text-sm" {...field} data-testid="dlg-airline" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="fare" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Fare (QAR)</FormLabel>
                  <FormControl><Input type="number" placeholder="1250" className="h-10 rounded-lg bg-slate-50 border-slate-200 text-sm" {...field} data-testid="dlg-fare" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="baggage" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Baggage</FormLabel>
                  <FormControl><Input placeholder="30 kg" className="h-10 rounded-lg bg-slate-50 border-slate-200 text-sm" {...field} data-testid="dlg-baggage" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <FormField control={form.control} name="flightType" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger className="h-10 rounded-lg bg-slate-50 border-slate-200 text-sm" data-testid="dlg-type">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Direct">Direct</SelectItem>
                      <SelectItem value="1 Stop">1 Stop</SelectItem>
                    </SelectContent>
                  </Select>
                </FormItem>
              )} />
              <FormField control={form.control} name="transitAirport" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Transit</FormLabel>
                  <FormControl><Input placeholder="Dubai (DXB)" disabled={flightType === "Direct"} className={cn("h-10 rounded-lg bg-slate-50 border-slate-200 text-sm", flightType === "Direct" && "opacity-40")} {...field} data-testid="dlg-transit" /></FormControl>
                </FormItem>
              )} />
              <FormField control={form.control} name="layoverTime" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Layover</FormLabel>
                  <FormControl><Input placeholder="2h 30m" disabled={flightType === "Direct"} className={cn("h-10 rounded-lg bg-slate-50 border-slate-200 text-sm", flightType === "Direct" && "opacity-40")} {...field} data-testid="dlg-layover" /></FormControl>
                </FormItem>
              )} />
              <FormField control={form.control} name="totalJourneyTime" render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Journey</FormLabel>
                  <FormControl><Input placeholder="8h 15m" className="h-10 rounded-lg bg-slate-50 border-slate-200 text-sm" {...field} data-testid="dlg-journey" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="remarks" render={({ field }) => (
              <FormItem>
                <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Remarks</FormLabel>
                <FormControl><Textarea placeholder="Optional notes..." className="rounded-lg bg-slate-50 border-slate-200 text-sm resize-none h-16" {...field} data-testid="dlg-remarks" /></FormControl>
              </FormItem>
            )} />
            <div className="flex justify-end gap-2 pt-1">
              <Button type="button" variant="outline" onClick={onClose} className="rounded-lg">Cancel</Button>
              <Button type="submit" className="rounded-lg gap-2" data-testid="dlg-save">
                <Save className="w-4 h-4" />
                {editFlight ? "Update Flight" : "Save Flight"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

// ─── Tab 1: New Enquiry ───────────────────────────────────────────────────────
const enquirySchema = z.object({
  customerName: z.string().min(1, "Customer name is required"),
  whatsappNumber: z.string().min(1, "WhatsApp number is required"),
  from: z.string().min(1, "Origin required"),
  to: z.string().min(1, "Destination required"),
  tripType: z.enum(["one-way", "round-trip"]),
  departureDateStart: z.date({ required_error: "Required" }),
  departureDateEnd: z.date({ required_error: "Required" }),
  returnDateStart: z.date().optional(),
  returnDateEnd: z.date().optional(),
  adults: z.number().min(1),
  children: z.number().min(0),
  infants: z.number().min(0),
  flightPreference: z.enum(["direct-only", "direct-connection"]),
  baggagePreference: z.enum(["cabin-only", "check-in"]),
  specialRequests: z.array(z.string()),
}).superRefine((d, ctx) => {
  if (d.departureDateEnd && d.departureDateStart && d.departureDateEnd < d.departureDateStart) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Must be on or after start", path: ["departureDateEnd"] });
  }
  if (d.tripType === "round-trip") {
    if (!d.returnDateStart) ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Required for round trip", path: ["returnDateStart"] });
    if (!d.returnDateEnd)   ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Required for round trip", path: ["returnDateEnd"] });
  }
});
type EnquiryValues = z.infer<typeof enquirySchema>;

const SPECIAL_REQUESTS = [
  { id: "meal",           label: "Meal" },
  { id: "seat",           label: "Seat" },
  { id: "wheelchair",     label: "Wheelchair" },
  { id: "extra-baggage",  label: "Extra Baggage" },
];

function NewEnquiryTab({ onCreated }: { onCreated: () => void }) {
  const { toast } = useToast();
  const saved = loadJson<Partial<EnquiryValues> & { departureDateStart?: string; departureDateEnd?: string; returnDateStart?: string; returnDateEnd?: string }>(ENQUIRY_KEY, {});

  const form = useForm<EnquiryValues>({
    resolver: zodResolver(enquirySchema),
    defaultValues: {
      customerName: (saved.customerName as string) ?? "",
      whatsappNumber: (saved.whatsappNumber as string) ?? "",
      from: (saved.from as string) ?? "Doha (DOH)",
      to: (saved.to as string) ?? "Kochi (COK)",
      tripType: (saved.tripType as "one-way" | "round-trip") ?? "round-trip",
      adults: (saved.adults as number) ?? 1,
      children: (saved.children as number) ?? 0,
      infants: (saved.infants as number) ?? 0,
      flightPreference: (saved.flightPreference as "direct-only" | "direct-connection") ?? "direct-connection",
      baggagePreference: (saved.baggagePreference as "cabin-only" | "check-in") ?? "check-in",
      specialRequests: (saved.specialRequests as string[]) ?? [],
    },
  });

  const tripType = form.watch("tripType");

  const stepField = (name: "adults" | "children" | "infants", delta: number, min = 0) => {
    const v = form.getValues(name);
    const next = v + delta;
    if (next < min) return;
    form.setValue(name, next, { shouldValidate: true });
  };

  const onSubmit = (data: EnquiryValues) => {
    saveJson(ENQUIRY_KEY, data);
    toast({ title: "Enquiry created!", description: `${data.customerName} — ${data.from} → ${data.to}` });
    onCreated();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-800">New Enquiry</h2>
          <p className="text-sm text-slate-500">Enter customer details and travel requirements</p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Customer Details */}
          <Card className="border border-slate-200 shadow-sm">
            <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
              <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
                <UserCircle className="w-4 h-4 text-primary" /> Customer Details
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField control={form.control} name="customerName" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Customer Name</FormLabel>
                    <FormControl><Input placeholder="Full name" className="h-10 rounded-lg bg-slate-50 border-slate-200" {...field} data-testid="input-customer-name" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="whatsappNumber" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">WhatsApp Number</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Phone className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                        <Input placeholder="+974 XXXX XXXX" className="h-10 pl-9 rounded-lg bg-slate-50 border-slate-200" {...field} data-testid="input-whatsapp" />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
            </CardContent>
          </Card>

          {/* Flight Details */}
          <Card className="border border-slate-200 shadow-sm">
            <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
              <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
                <Plane className="w-4 h-4 text-primary" /> Flight Details
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-5">
              {/* From / To / Trip Type */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                <FormField control={form.control} name="from" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">From</FormLabel>
                    <FormControl><Input placeholder="Doha (DOH)" className="h-10 rounded-lg bg-slate-50 border-slate-200" {...field} data-testid="input-from" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="to" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">To</FormLabel>
                    <FormControl><Input placeholder="Kochi (COK)" className="h-10 rounded-lg bg-slate-50 border-slate-200" {...field} data-testid="input-to" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="tripType" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Trip Type</FormLabel>
                    <FormControl>
                      <RadioGroup onValueChange={field.onChange} value={field.value} className="flex gap-4 h-10 items-center" data-testid="radio-triptype">
                        <FormItem className="flex items-center gap-2 space-y-0">
                          <FormControl><RadioGroupItem value="round-trip" /></FormControl>
                          <FormLabel className="font-normal cursor-pointer text-sm">Round Trip</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center gap-2 space-y-0">
                          <FormControl><RadioGroupItem value="one-way" /></FormControl>
                          <FormLabel className="font-normal cursor-pointer text-sm">One Way</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                  </FormItem>
                )} />
              </div>

              {/* Departure Date Range */}
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <CalendarIcon className="w-3.5 h-3.5" /> Departure Date Range
                </p>
                <div className="grid grid-cols-2 gap-3 pl-5">
                  <FormField control={form.control} name="departureDateStart" render={({ field }) => (
                    <FormItem>
                      <FormControl><DatePicker label="Start Date" value={field.value} onChange={field.onChange} testId="btn-dep-start" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="departureDateEnd" render={({ field }) => (
                    <FormItem>
                      <FormControl><DatePicker label="End Date" value={field.value} onChange={field.onChange} testId="btn-dep-end" minDate={form.getValues("departureDateStart")} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </div>

              {/* Return Date Range (conditional) */}
              <AnimatePresence>
                {tripType === "round-trip" && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.25 }} className="space-y-2 overflow-hidden">
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                      <CalendarIcon className="w-3.5 h-3.5" /> Return Date Range
                    </p>
                    <div className="grid grid-cols-2 gap-3 pl-5">
                      <FormField control={form.control} name="returnDateStart" render={({ field }) => (
                        <FormItem>
                          <FormControl><DatePicker label="Start Date" value={field.value} onChange={field.onChange} testId="btn-ret-start" minDate={form.getValues("departureDateEnd")} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={form.control} name="returnDateEnd" render={({ field }) => (
                        <FormItem>
                          <FormControl><DatePicker label="End Date" value={field.value} onChange={field.onChange} testId="btn-ret-end" minDate={form.getValues("returnDateStart")} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>

          {/* Passengers */}
          <Card className="border border-slate-200 shadow-sm">
            <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
              <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" /> Passengers
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {([
                  { name: "adults",   label: "Adults",   sub: "12+ yrs",    min: 1 },
                  { name: "children", label: "Children", sub: "2–11 yrs",   min: 0 },
                  { name: "infants",  label: "Infants",  sub: "Under 2 yrs", min: 0 },
                ] as const).map(({ name, label, sub, min }) => (
                  <FormField key={name} control={form.control} name={name} render={({ field }) => (
                    <FormItem>
                      <Stepper label={label} sub={sub} value={field.value}
                        onDecrement={() => stepField(name, -1, min)}
                        onIncrement={() => stepField(name, 1)}
                        min={min} testId={`stepper-${name}`} />
                    </FormItem>
                  )} />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Preferences */}
          <Card className="border border-slate-200 shadow-sm">
            <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
              <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
                <ClipboardList className="w-4 h-4 text-primary" /> Preferences &amp; Requests
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-6">
              {/* Flight Preference */}
              <FormField control={form.control} name="flightPreference" render={({ field }) => (
                <FormItem className="space-y-2">
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Flight Preference</FormLabel>
                  <FormControl>
                    <RadioGroup onValueChange={field.onChange} value={field.value} className="space-y-2" data-testid="radio-flight-pref">
                      <FormItem className="flex items-center gap-2.5 space-y-0 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                        <FormControl><RadioGroupItem value="direct-only" /></FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">Direct Only</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center gap-2.5 space-y-0 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                        <FormControl><RadioGroupItem value="direct-connection" /></FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">Direct + Connection</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                </FormItem>
              )} />

              {/* Baggage Preference */}
              <FormField control={form.control} name="baggagePreference" render={({ field }) => (
                <FormItem className="space-y-2">
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Baggage Preference</FormLabel>
                  <FormControl>
                    <RadioGroup onValueChange={field.onChange} value={field.value} className="space-y-2" data-testid="radio-baggage-pref">
                      <FormItem className="flex items-center gap-2.5 space-y-0 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                        <FormControl><RadioGroupItem value="cabin-only" /></FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">Cabin Only</FormLabel>
                      </FormItem>
                      <FormItem className="flex items-center gap-2.5 space-y-0 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                        <FormControl><RadioGroupItem value="check-in" /></FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">Check-in Baggage</FormLabel>
                      </FormItem>
                    </RadioGroup>
                  </FormControl>
                </FormItem>
              )} />

              {/* Special Requests */}
              <FormField control={form.control} name="specialRequests" render={({ field }) => (
                <FormItem className="space-y-2">
                  <FormLabel className="text-xs text-muted-foreground uppercase tracking-wider">Special Requests</FormLabel>
                  <div className="space-y-2">
                    {SPECIAL_REQUESTS.map(req => (
                      <FormItem key={req.id} className="flex items-center gap-2.5 space-y-0 p-2.5 rounded-lg border border-slate-200 bg-slate-50 cursor-pointer">
                        <FormControl>
                          <Checkbox
                            checked={(field.value ?? []).includes(req.id)}
                            onCheckedChange={checked => {
                              const cur = field.value ?? [];
                              field.onChange(checked ? [...cur, req.id] : cur.filter(v => v !== req.id));
                            }}
                            data-testid={`checkbox-${req.id}`}
                          />
                        </FormControl>
                        <FormLabel className="font-normal text-sm cursor-pointer">{req.label}</FormLabel>
                      </FormItem>
                    ))}
                  </div>
                </FormItem>
              )} />
            </CardContent>
          </Card>

          <Button type="submit" size="lg" className="w-full h-12 rounded-xl font-semibold shadow-md hover:shadow-lg gap-2" data-testid="btn-create-enquiry">
            <CheckCircle2 className="w-5 h-5" />
            Create Enquiry
          </Button>
        </form>
      </Form>
    </div>
  );
}

// ─── Tab 2: Flight Search Rules ───────────────────────────────────────────────
function SearchRulesTab() {
  const { toast } = useToast();
  const [rules, setRules] = useState<SearchRules>(() =>
    loadJson(RULES_KEY, { maxLayoverHours: 10, preferred: DEFAULT_PREFERRED, avoid: DEFAULT_AVOID })
  );

  const update = (partial: Partial<SearchRules>) => {
    const next = { ...rules, ...partial };
    setRules(next);
    saveJson(RULES_KEY, next);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-slate-800">Flight Search Rules</h2>
        <p className="text-sm text-slate-500">Define the agent's filtering preferences for this search</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        {/* Max Layover */}
        <Card className="border border-slate-200 shadow-sm">
          <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
            <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" /> Maximum Layover
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            <Stepper label="Max Layover" sub="hours allowed" value={rules.maxLayoverHours}
              onDecrement={() => rules.maxLayoverHours > 1 && update({ maxLayoverHours: rules.maxLayoverHours - 1 })}
              onIncrement={() => rules.maxLayoverHours < 48 && update({ maxLayoverHours: rules.maxLayoverHours + 1 })}
              min={1} testId="stepper-layover" />
            <p className="text-xs text-slate-400 mt-2 text-center">Layovers over 6h will show a warning</p>
          </CardContent>
        </Card>

        {/* Preferred */}
        <Card className="border border-slate-200 shadow-sm">
          <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
            <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-600" /> Preferred Transits
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            <AirportTags label="" tags={rules.preferred} onChange={preferred => update({ preferred })}
              colorClass="bg-green-100 text-green-800 border-green-200 hover:bg-green-100"
              testId="tags-preferred" />
          </CardContent>
        </Card>

        {/* Avoid */}
        <Card className="border border-slate-200 shadow-sm">
          <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
            <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" /> Avoid if Possible
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4">
            <AirportTags label="" tags={rules.avoid} onChange={avoid => update({ avoid })}
              colorClass="bg-red-100 text-red-700 border-red-200 hover:bg-red-100"
              testId="tags-avoid" />
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 text-blue-700 rounded-xl px-4 py-3 text-sm">
        <Shield className="w-4 h-4 flex-shrink-0" />
        Rules are saved automatically and applied to all flight highlights in the Results Manager.
      </div>
    </div>
  );
}

// ─── Tab 3: Flight Results Manager ───────────────────────────────────────────
function FlightResultsTab() {
  const [flights, setFlights] = useState<SavedFlight[]>(() => loadJson(FLIGHTS_KEY, []));
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingFlight, setEditingFlight] = useState<SavedFlight | null>(null);
  const { toast } = useToast();
  const rules = loadJson<SearchRules>(RULES_KEY, { maxLayoverHours: 10, preferred: DEFAULT_PREFERRED, avoid: DEFAULT_AVOID });

  useEffect(() => { saveJson(FLIGHTS_KEY, flights); }, [flights]);

  const cheapestDirect = getCheapestDirect(flights);
  const cheapestConn   = getCheapestConnecting(flights);
  const bestFamily     = getBestFamily(flights, rules.preferred, rules.avoid);
  const fastest        = getFastest(flights);

  const handleSave = (flight: SavedFlight) => {
    setFlights(prev => {
      if (prev.find(f => f.id === flight.id)) return prev.map(f => f.id === flight.id ? flight : f);
      return [flight, ...prev];
    });
  };

  const openAdd  = () => { setEditingFlight(null); setDialogOpen(true); };
  const openEdit = (f: SavedFlight) => { setEditingFlight(f); setDialogOpen(true); };
  const deleteFlight = (id: string) => {
    setFlights(prev => prev.filter(f => f.id !== id));
    toast({ title: "Flight removed" });
  };

  const getHighlight = (f: SavedFlight) => {
    if (cheapestDirect?.id === f.id) return { bg: "bg-green-50/70", badge: <Badge className="text-[10px] bg-green-100 text-green-700 border border-green-200 hover:bg-green-100">Cheapest Direct</Badge> };
    if (cheapestConn?.id   === f.id) return { bg: "bg-blue-50/70",  badge: <Badge className="text-[10px] bg-blue-100 text-blue-700 border border-blue-200 hover:bg-blue-100">Cheapest Connect</Badge> };
    if (bestFamily?.id     === f.id) return { bg: "bg-rose-50/70",  badge: <Badge className="text-[10px] bg-rose-100 text-rose-700 border border-rose-200 hover:bg-rose-100">Best Family</Badge> };
    if (fastest?.id        === f.id) return { bg: "bg-violet-50/70",badge: <Badge className="text-[10px] bg-violet-100 text-violet-700 border border-violet-200 hover:bg-violet-100">Fastest</Badge> };
    return { bg: "", badge: null };
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-800">Flight Results Manager</h2>
          <p className="text-sm text-slate-500">Manually enter and manage flight options for this enquiry</p>
        </div>
        <Button onClick={openAdd} className="gap-2 rounded-lg" data-testid="btn-add-flight">
          <Plus className="w-4 h-4" /> Add Flight
        </Button>
      </div>

      {/* Highlight cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <FlightHighlightCard icon={<TrendingDown className="w-4 h-4 text-white"/>} iconBg="bg-green-500" label="Cheapest Direct" flight={cheapestDirect} delay={0.05} />
        <FlightHighlightCard icon={<Wifi className="w-4 h-4 text-white"/>} iconBg="bg-blue-500" label="Cheapest Connect" flight={cheapestConn} delay={0.1} />
        <FlightHighlightCard icon={<Heart className="w-4 h-4 text-white"/>} iconBg="bg-rose-500" label="Best Family Option" flight={bestFamily} delay={0.15} />
        <FlightHighlightCard icon={<Zap className="w-4 h-4 text-white"/>} iconBg="bg-violet-500" label="Fastest Journey" flight={fastest} delay={0.2} />
      </div>

      {/* Legend */}
      {flights.length > 0 && (
        <div className="flex flex-wrap gap-3 text-xs text-slate-500">
          {[["bg-green-200 border-green-400","Cheapest Direct"],["bg-blue-200 border-blue-400","Cheapest Connect"],["bg-rose-200 border-rose-400","Best Family"],["bg-violet-200 border-violet-400","Fastest"]].map(([cls, lbl]) => (
            <span key={lbl} className="flex items-center gap-1.5">
              <span className={`inline-block w-2.5 h-2.5 rounded-full border ${cls}`} />{lbl}
            </span>
          ))}
        </div>
      )}

      {/* Table */}
      <Card className="border border-slate-200 shadow-sm overflow-hidden">
        <CardContent className="p-0">
          {flights.length === 0 ? (
            <div className="py-16 text-center text-slate-400">
              <Plane className="w-10 h-10 mx-auto mb-3 opacity-25" />
              <p className="font-medium text-slate-500">No flights added yet</p>
              <p className="text-sm mt-1">Click "Add Flight" to get started</p>
            </div>
          ) : (
            <Table data-testid="table-flights">
              <TableHeader>
                <TableRow className="bg-slate-50 hover:bg-slate-50">
                  {["Date","Airline","Fare (QAR)","Baggage","Type","Transit","Layover","Journey","Remarks",""].map(h => (
                    <TableHead key={h} className="px-3 py-3 text-xs font-semibold text-slate-600 uppercase tracking-wide whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {flights.map((f, i) => {
                  const { bg, badge } = getHighlight(f);
                  const long = f.layoverMinutes >= 360;
                  return (
                    <motion.tr key={f.id} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.2, delay: 0.03 * i }}
                      className={`border-b last:border-0 hover:brightness-[0.97] transition-all ${bg}`}
                      data-testid={`row-flight-${f.id}`}>
                      <TableCell className="px-3 py-2.5 text-sm text-slate-600 whitespace-nowrap">{f.date}</TableCell>
                      <TableCell className="px-3 py-2.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-sm font-medium text-slate-800 whitespace-nowrap">{f.airline}</span>
                          {badge}
                        </div>
                      </TableCell>
                      <TableCell className="px-3 py-2.5 text-right font-bold text-primary text-sm whitespace-nowrap">{f.fare.toLocaleString()}</TableCell>
                      <TableCell className="px-3 py-2.5 text-sm text-slate-600 whitespace-nowrap">{f.baggage}</TableCell>
                      <TableCell className="px-3 py-2.5">
                        <Badge variant="outline" className={`text-xs whitespace-nowrap ${f.flightType === "Direct" ? "bg-green-50 text-green-700 border-green-200" : "bg-blue-50 text-blue-700 border-blue-200"}`}>
                          {f.flightType}
                        </Badge>
                      </TableCell>
                      <TableCell className="px-3 py-2.5 text-sm text-slate-600 whitespace-nowrap">{f.transitAirport}</TableCell>
                      <TableCell className="px-3 py-2.5 whitespace-nowrap">
                        {long ? (
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-amber-700 font-medium">{f.layoverTime}</span>
                            <span className="inline-flex items-center gap-0.5 bg-amber-100 text-amber-700 border border-amber-300 rounded px-1.5 py-0.5 text-[10px] font-semibold" data-testid={`warn-layover-${f.id}`}>
                              <AlertTriangle className="w-2.5 h-2.5"/>Long Layover — Not Recommended for Families
                            </span>
                          </div>
                        ) : (
                          <span className="text-sm text-slate-600">{f.layoverTime}</span>
                        )}
                      </TableCell>
                      <TableCell className="px-3 py-2.5 text-sm text-slate-600 whitespace-nowrap">{f.totalJourneyTime}</TableCell>
                      <TableCell className="px-3 py-2.5 text-sm text-slate-500 min-w-[120px]">{f.remarks || "—"}</TableCell>
                      <TableCell className="px-3 py-2.5">
                        <div className="flex items-center gap-1">
                          <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-primary hover:bg-blue-50 rounded-md"
                            onClick={() => openEdit(f)} data-testid={`btn-edit-${f.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md"
                            onClick={() => deleteFlight(f.id)} data-testid={`btn-delete-${f.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </motion.tr>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <FlightFormDialog open={dialogOpen} onClose={() => setDialogOpen(false)} editFlight={editingFlight} onSave={handleSave} />
    </div>
  );
}

// ─── Tab 4: WhatsApp Quote ────────────────────────────────────────────────────
function WhatsAppQuoteTab() {
  const { toast } = useToast();
  const [preview, setPreview] = useState("");

  const generate = () => {
    const enquiry = loadJson<Record<string, unknown>>(ENQUIRY_KEY, {});
    const rules   = loadJson<SearchRules>(RULES_KEY, { maxLayoverHours: 10, preferred: DEFAULT_PREFERRED, avoid: DEFAULT_AVOID });
    const flights: SavedFlight[] = loadJson(FLIGHTS_KEY, []);

    const cheapestDirect = getCheapestDirect(flights);
    const cheapestConn   = getCheapestConnecting(flights);
    const bestFamily     = getBestFamily(flights, rules.preferred, rules.avoid);

    const name   = String(enquiry.customerName ?? "—");
    const from   = String(enquiry.from ?? "Doha (DOH)");
    const to     = String(enquiry.to ?? "Kerala");
    const adults = Number(enquiry.adults ?? 1);
    const children = Number(enquiry.children ?? 0);
    const infants  = Number(enquiry.infants ?? 0);

    const pax = [
      adults > 0   ? `${adults} Adult${adults > 1 ? "s" : ""}` : "",
      children > 0 ? `${children} Child${children > 1 ? "ren" : ""}` : "",
      infants > 0  ? `${infants} Infant${infants > 1 ? "s" : ""}` : "",
    ].filter(Boolean).join(", ");

    const depStart = enquiry.departureDateStart ? format(new Date(String(enquiry.departureDateStart)), "dd MMM yyyy") : "—";
    const depEnd   = enquiry.departureDateEnd   ? format(new Date(String(enquiry.departureDateEnd)),   "dd MMM yyyy") : "—";

    const flightBlock = (label: string, emoji: string, f: SavedFlight | undefined): string => {
      if (!f) return `${emoji} ${label}\n(No matching flight found)\n`;
      const lines = [
        `${emoji} *${label}*`,
        `✈ ${f.airline}`,
        `📅 ${f.date}`,
        `💰 QAR ${f.fare.toLocaleString()}`,
        `🧳 Baggage: ${f.baggage}`,
        f.flightType === "1 Stop" ? `📍 Via: ${f.transitAirport}  |  ⏳ Layover: ${f.layoverTime}` : `✅ Non-stop flight`,
        `⏱ Journey: ${f.totalJourneyTime}`,
        f.remarks ? `📝 ${f.remarks}` : "",
      ].filter(Boolean);
      return lines.join("\n");
    };

    const msg = [
      `✈ *RAMIEL TRIPMARKER*`,
      `_Flight Search Assistant_`,
      `━━━━━━━━━━━━━━━━━━━━━━━━`,
      `👤 Customer: ${name}`,
      `🛫 Route: ${from} → ${to}`,
      `📅 Travel Dates: ${depStart} – ${depEnd}`,
      `👥 Passengers: ${pax}`,
      `━━━━━━━━━━━━━━━━━━━━━━━━`,
      ``,
      flightBlock("OPTION 1 — Cheapest Direct", "1️⃣", cheapestDirect),
      ``,
      `━━━━━━━━━━━━━━━━━━━━━━━━`,
      ``,
      flightBlock("OPTION 2 — Cheapest Connection", "2️⃣", cheapestConn),
      ``,
      `━━━━━━━━━━━━━━━━━━━━━━━━`,
      ``,
      flightBlock("OPTION 3 — Best Family Option", "3️⃣", bestFamily),
      ``,
      `━━━━━━━━━━━━━━━━━━━━━━━━`,
      `🙏 Thank you for choosing *RAMIEL TRIPMARKER*!`,
      `For bookings, please reply to this message.`,
    ].join("\n");

    setPreview(msg);
  };

  useEffect(() => { generate(); }, []);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(preview);
      toast({ title: "Copied to clipboard!", description: "Paste into WhatsApp." });
    } catch {
      toast({ title: "Copy failed", description: "Please select and copy the text manually." });
    }
  };

  const openWhatsApp = () => {
    const phone = loadJson<Record<string,unknown>>(ENQUIRY_KEY, {}).whatsappNumber as string | undefined;
    const num = phone ? phone.replace(/\D/g, "") : "";
    const encoded = encodeURIComponent(preview);
    window.open(num ? `https://wa.me/${num}?text=${encoded}` : `https://wa.me/?text=${encoded}`, "_blank");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-800">WhatsApp Quote</h2>
          <p className="text-sm text-slate-500">Generate a formatted quote message to send to the customer</p>
        </div>
        <Button variant="outline" size="sm" className="gap-2 rounded-lg" onClick={generate} data-testid="btn-refresh-quote">
          <CheckCircle2 className="w-4 h-4" /> Refresh
        </Button>
      </div>

      {/* Preview */}
      <Card className="border border-slate-200 shadow-sm">
        <CardHeader className="py-3 px-4 border-b border-slate-100 bg-slate-50/60">
          <CardTitle className="text-sm font-semibold text-slate-600 flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-green-600" /> Message Preview
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="bg-[#ECE5DD] rounded-xl p-4 min-h-[200px]">
            <div className="bg-white rounded-xl px-4 py-3 shadow-sm max-w-lg mx-auto">
              <pre className="text-xs text-slate-800 whitespace-pre-wrap font-sans leading-relaxed">{preview || "Click Refresh to generate the quote."}</pre>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Button variant="outline" size="lg" className="h-12 rounded-xl gap-2 border-slate-300" onClick={copyToClipboard} data-testid="btn-copy-quote">
          <Copy className="w-5 h-5" /> Copy to Clipboard
        </Button>
        <Button size="lg" className="h-12 rounded-xl gap-2 bg-[#25D366] hover:bg-[#1ebe5d] text-white shadow-md" onClick={openWhatsApp} data-testid="btn-open-whatsapp">
          <ExternalLink className="w-5 h-5" /> Generate WhatsApp Quote
        </Button>
      </div>

      <p className="text-xs text-center text-slate-400">
        The quote uses flight data from the Results Manager and customer info from the Enquiry form.
      </p>
    </div>
  );
}

// ─── Main Dashboard ───────────────────────────────────────────────────────────
export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("enquiry");

  return (
    <div className="min-h-screen bg-[#F1F5F9]">
      {/* Branded header */}
      <header className="bg-[#0B1E3D] border-b border-[#1a3260] shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-0">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-amber-500 rounded-lg flex items-center justify-center shadow-md">
                <Plane className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-white font-bold text-base leading-tight tracking-wide">RAMIEL TRIPMARKER</p>
                <p className="text-blue-300 text-xs leading-tight">Flight Search Assistant</p>
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-blue-300 text-xs">
              <span className="bg-blue-900/60 px-2.5 py-1 rounded-full border border-blue-800">Qatar → Kerala Specialist</span>
            </div>
          </div>
        </div>
      </header>

      {/* Tab bar */}
      <div className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="h-auto bg-transparent p-0 gap-0 rounded-none w-full justify-start">
              {[
                { value: "enquiry",  icon: <UserCircle className="w-4 h-4"/>,     label: "New Enquiry" },
                { value: "rules",    icon: <Shield className="w-4 h-4"/>,          label: "Flight Search Rules" },
                { value: "results",  icon: <ClipboardList className="w-4 h-4"/>,   label: "Results Manager" },
                { value: "whatsapp", icon: <MessageCircle className="w-4 h-4"/>,   label: "WhatsApp Quote" },
              ].map(tab => (
                <TabsTrigger key={tab.value} value={tab.value}
                  className={cn(
                    "flex items-center gap-2 px-4 py-3.5 rounded-none border-b-2 text-sm font-medium transition-all",
                    "data-[state=inactive]:border-transparent data-[state=inactive]:text-slate-500 data-[state=inactive]:hover:text-slate-700 data-[state=inactive]:bg-transparent",
                    "data-[state=active]:border-primary data-[state=active]:text-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none"
                  )}
                  data-testid={`tab-${tab.value}`}>
                  {tab.icon}{tab.label}
                </TabsTrigger>
              ))}
            </TabsList>

            {/* Tab content */}
            <div className="max-w-7xl mx-auto">
              <TabsContent value="enquiry"  className="mt-0 pt-0">
                <div className="py-6 px-0"><NewEnquiryTab onCreated={() => setActiveTab("rules")} /></div>
              </TabsContent>
              <TabsContent value="rules"   className="mt-0 pt-0">
                <div className="py-6 px-0"><SearchRulesTab /></div>
              </TabsContent>
              <TabsContent value="results"  className="mt-0 pt-0">
                <div className="py-6 px-0"><FlightResultsTab /></div>
              </TabsContent>
              <TabsContent value="whatsapp" className="mt-0 pt-0">
                <div className="py-6 px-0"><WhatsAppQuoteTab /></div>
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
