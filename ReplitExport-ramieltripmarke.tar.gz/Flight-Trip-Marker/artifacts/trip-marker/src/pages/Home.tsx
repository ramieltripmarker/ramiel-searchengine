import { useState, useRef } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { useLocation } from "wouter";
import {
  Plane,
  MapPin,
  Calendar as CalendarIcon,
  Users,
  ScanSearch,
  Minus,
  Plus,
  ShieldCheck,
  X,
  Clock,
  ClipboardList,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const formSchema = z
  .object({
    from: z.string().min(1, "Please enter origin city or airport"),
    to: z.string().min(1, "Please enter destination city or airport"),
    tripType: z.enum(["one-way", "round-trip"]),
    departureDateStart: z.date({ required_error: "Please select a start date." }),
    departureDateEnd: z.date({ required_error: "Please select an end date." }),
    returnDateStart: z.date().optional(),
    returnDateEnd: z.date().optional(),
    adults: z.number().min(1, "At least 1 adult is required"),
    children: z.number().min(0),
    infants: z.number().min(0),
    directFlights: z.boolean().default(false),
    connectingFlights: z.boolean().default(false),
    maxLayoverHours: z.number().min(1).max(48),
    preferredTransitAirports: z.array(z.string()),
    avoidTransitAirports: z.array(z.string()),
  })
  .superRefine((data, ctx) => {
    if (data.departureDateEnd < data.departureDateStart) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "End date must be on or after start date",
        path: ["departureDateEnd"],
      });
    }
    if (data.tripType === "round-trip") {
      if (!data.returnDateStart) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Return start date is required for round trips",
          path: ["returnDateStart"],
        });
      }
      if (!data.returnDateEnd) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Return end date is required for round trips",
          path: ["returnDateEnd"],
        });
      }
      if (data.returnDateStart && data.returnDateEnd && data.returnDateEnd < data.returnDateStart) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "End date must be on or after start date",
          path: ["returnDateEnd"],
        });
      }
    }
  });

type FormValues = z.infer<typeof formSchema>;

function DatePickerField({
  label,
  value,
  onChange,
  testId,
  minDate,
}: {
  label: string;
  value: Date | undefined;
  onChange: (d: Date | undefined) => void;
  testId: string;
  minDate?: Date;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-muted-foreground text-xs uppercase tracking-wider font-medium">
        {label}
      </span>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            className={cn(
              "w-full h-11 pl-3 text-left font-medium rounded-xl bg-slate-50 border-transparent hover:bg-slate-100",
              !value && "text-muted-foreground"
            )}
            data-testid={testId}
          >
            <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground/60" />
            {value ? format(value, "MMM d, yyyy") : <span>Select date</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0 rounded-2xl" align="start">
          <Calendar
            mode="single"
            selected={value}
            onSelect={onChange}
            disabled={(date) => {
              const floor = minDate ?? new Date(new Date().setHours(0, 0, 0, 0));
              return date < floor;
            }}
            initialFocus
            className="p-3"
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}

function AirportTagInput({
  label,
  tags,
  onChange,
  testId,
  colorClass,
}: {
  label: string;
  tags: string[];
  onChange: (tags: string[]) => void;
  testId: string;
  colorClass: string;
}) {
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const safeTags = tags ?? [];

  const addTag = (raw: string) => {
    const code = raw.trim().toUpperCase();
    if (code.length >= 2 && code.length <= 4 && !safeTags.includes(code)) {
      onChange([...safeTags, code]);
    }
    setInput("");
  };

  const removeTag = (code: string) => {
    onChange(safeTags.filter((t) => t !== code));
  };

  return (
    <div className="space-y-2" data-testid={testId}>
      <span className="text-slate-700 text-sm font-medium">{label}</span>
      <div
        className="flex flex-wrap gap-2 p-3 rounded-xl bg-slate-50 min-h-[48px] cursor-text"
        onClick={() => inputRef.current?.focus()}
      >
        {safeTags.map((code) => (
          <Badge
            key={code}
            className={`gap-1 text-xs font-semibold pr-1 ${colorClass}`}
          >
            {code}
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); removeTag(code); }}
              className="ml-0.5 hover:opacity-70 transition-opacity"
              aria-label={`Remove ${code}`}
            >
              <X className="w-3 h-3" />
            </button>
          </Badge>
        ))}
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value.toUpperCase())}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === "," || e.key === " ") {
              e.preventDefault();
              addTag(input);
            }
            if (e.key === "Backspace" && input === "" && tags.length > 0) {
              onChange(tags.slice(0, -1));
            }
          }}
          onBlur={() => { if (input) addTag(input); }}
          placeholder={tags.length === 0 ? "Type code + Enter" : "Add…"}
          maxLength={4}
          className="bg-transparent outline-none text-xs font-mono placeholder:text-slate-400 w-20 flex-shrink-0"
        />
      </div>
    </div>
  );
}

export default function Home() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      from: "",
      to: "",
      tripType: "round-trip",
      adults: 1,
      children: 0,
      infants: 0,
      directFlights: false,
      connectingFlights: false,
      maxLayoverHours: 10,
      preferredTransitAirports: ["BLR", "MAA", "CMB", "COK", "CCJ", "CNN", "TRV"],
      avoidTransitAirports: ["BOM", "DEL"],
    },
  });

  const tripType = form.watch("tripType");

  const onSubmit = (data: FormValues) => {
    try {
      sessionStorage.setItem("tripMarkerSearch", JSON.stringify(data));
    } catch {
      // ignore storage errors
    }
    toast({
      title: "Scanning date range...",
      description: `From ${data.from} to ${data.to}`,
    });
    setTimeout(() => setLocation("/results"), 400);
  };

  const handleStepper = (
    field: "adults" | "children" | "infants" | "maxLayoverHours",
    increment: boolean,
    min = 0,
    max = 999
  ) => {
    const currentValue = form.getValues(field);
    const next = increment ? currentValue + 1 : currentValue - 1;
    if (next < min || next > max) return;
    form.setValue(field, next, { shouldValidate: true });
  };

  return (
    <div className="min-h-screen w-full relative flex items-start justify-center pt-16 pb-16 px-4">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="/hero-bg.jpg"
          alt="Sky background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-blue-950/40 via-blue-900/30 to-background/90" />
      </div>

      <div className="z-10 w-full max-w-5xl mx-auto flex flex-col items-center">

        {/* Hero title */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center mb-10"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-primary/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
              <Plane className="w-6 h-6 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white tracking-tight mb-4 drop-shadow-sm">
            Trip Marker <span className="font-light opacity-90">Flight Assistant</span>
          </h1>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-1 mb-2 gap-2 bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white backdrop-blur-sm"
            onClick={() => setLocation("/manager")}
            data-testid="btn-goto-manager"
          >
            <ClipboardList className="w-4 h-4" />
            Flight Results Manager
          </Button>
          <p className="text-lg md:text-xl text-blue-100 max-w-2xl mx-auto drop-shadow-sm">
            Find the perfect flight with ease. Experience seamless booking for your next adventure.
          </p>
        </motion.div>

        {/* Form card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.2 }}
          className="w-full"
        >
          <Card className="border-0 shadow-2xl bg-white/95 backdrop-blur-xl rounded-3xl overflow-hidden">
            <CardContent className="p-6 md:p-10">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">

                  {/* Trip Type */}
                  <FormField
                    control={form.control}
                    name="tripType"
                    render={({ field }) => (
                      <FormItem className="space-y-1">
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex gap-4"
                            data-testid="radio-triptype"
                          >
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="round-trip" data-testid="radio-triptype-round" />
                              </FormControl>
                              <FormLabel className="font-medium cursor-pointer">Round Trip</FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-2 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="one-way" data-testid="radio-triptype-oneway" />
                              </FormControl>
                              <FormLabel className="font-medium cursor-pointer">One Way</FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {/* Row 1: From + To */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="from"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-muted-foreground text-xs uppercase tracking-wider">From</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <MapPin className="absolute left-3 top-3 h-5 w-5 text-muted-foreground/60" />
                              <Input
                                placeholder="City or airport"
                                className="pl-10 h-12 text-base font-medium rounded-xl bg-slate-50 border-transparent focus-visible:bg-white"
                                data-testid="input-from"
                                {...field}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="to"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-muted-foreground text-xs uppercase tracking-wider">To</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <MapPin className="absolute left-3 top-3 h-5 w-5 text-muted-foreground/60" />
                              <Input
                                placeholder="City or airport"
                                className="pl-10 h-12 text-base font-medium rounded-xl bg-slate-50 border-transparent focus-visible:bg-white"
                                data-testid="input-to"
                                {...field}
                              />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Row 2: Departure Date Range */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <CalendarIcon className="w-4 h-4 text-muted-foreground" />
                      <h3 className="font-semibold text-slate-800 text-sm uppercase tracking-wider">
                        Departure Date Range
                      </h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pl-6">
                      <FormField
                        control={form.control}
                        name="departureDateStart"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <DatePickerField
                                label="Start Date"
                                value={field.value}
                                onChange={field.onChange}
                                testId="btn-departure-start"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="departureDateEnd"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <DatePickerField
                                label="End Date"
                                value={field.value}
                                onChange={field.onChange}
                                testId="btn-departure-end"
                                minDate={form.getValues("departureDateStart")}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Row 3: Return Date Range (Round Trip only) */}
                  <AnimatePresence>
                    {tripType === "round-trip" && (
                      <motion.div
                        initial={{ opacity: 0, height: 0, overflow: "hidden" }}
                        animate={{ opacity: 1, height: "auto", overflow: "visible" }}
                        exit={{ opacity: 0, height: 0, overflow: "hidden" }}
                        transition={{ duration: 0.3 }}
                        className="space-y-3"
                      >
                        <div className="flex items-center gap-2">
                          <CalendarIcon className="w-4 h-4 text-muted-foreground" />
                          <h3 className="font-semibold text-slate-800 text-sm uppercase tracking-wider">
                            Return Date Range
                          </h3>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pl-6">
                          <FormField
                            control={form.control}
                            name="returnDateStart"
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <DatePickerField
                                    label="Start Date"
                                    value={field.value}
                                    onChange={field.onChange}
                                    testId="btn-return-start"
                                    minDate={
                                      form.getValues("departureDateEnd") ??
                                      new Date(new Date().setHours(0, 0, 0, 0))
                                    }
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="returnDateEnd"
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <DatePickerField
                                    label="End Date"
                                    value={field.value}
                                    onChange={field.onChange}
                                    testId="btn-return-end"
                                    minDate={form.getValues("returnDateStart")}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div className="border-t border-slate-100" />

                  {/* Passengers + Flight Options */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">

                    {/* Passengers */}
                    <div className="lg:col-span-2 space-y-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="w-5 h-5 text-muted-foreground" />
                        <h3 className="font-semibold text-slate-800">Passengers</h3>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        {(
                          [
                            { name: "adults", label: "Adults", sub: "12+ yrs", min: 1 },
                            { name: "children", label: "Children", sub: "2-11 yrs", min: 0 },
                            { name: "infants", label: "Infants", sub: "Under 2 yrs", min: 0 },
                          ] as const
                        ).map(({ name, label, sub, min }) => (
                          <FormField
                            key={name}
                            control={form.control}
                            name={name}
                            render={({ field }) => (
                              <FormItem>
                                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50">
                                  <div>
                                    <FormLabel className="text-sm font-medium">{label}</FormLabel>
                                    <p className="text-xs text-muted-foreground">{sub}</p>
                                  </div>
                                  <div className="flex items-center gap-3">
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="icon"
                                      className="h-8 w-8 rounded-full border-slate-200 bg-white shadow-sm"
                                      onClick={() => handleStepper(name, false, min)}
                                      disabled={field.value <= min}
                                      data-testid={`btn-${name}-minus`}
                                    >
                                      <Minus className="h-3 w-3" />
                                    </Button>
                                    <span className="w-4 text-center font-medium text-sm" data-testid={`text-${name}`}>
                                      {field.value}
                                    </span>
                                    <Button
                                      type="button"
                                      variant="outline"
                                      size="icon"
                                      className="h-8 w-8 rounded-full border-slate-200 bg-white shadow-sm"
                                      onClick={() => handleStepper(name, true, min)}
                                      data-testid={`btn-${name}-plus`}
                                    >
                                      <Plus className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>
                              </FormItem>
                            )}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Flight Options */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Plane className="w-5 h-5 text-muted-foreground" />
                        <h3 className="font-semibold text-slate-800">Flight Options</h3>
                      </div>
                      <div className="space-y-4 p-4 rounded-xl bg-slate-50 flex flex-col justify-center">
                        <FormField
                          control={form.control}
                          name="directFlights"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  data-testid="checkbox-direct-flights"
                                />
                              </FormControl>
                              <FormLabel className="font-normal text-sm cursor-pointer">
                                Show Direct Flights
                              </FormLabel>
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="connectingFlights"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                  data-testid="checkbox-connecting-flights"
                                />
                              </FormControl>
                              <FormLabel className="font-normal text-sm cursor-pointer">
                                Show Connecting Flights
                              </FormLabel>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-slate-100" />

                  {/* Travel Agent Rules */}
                  <div className="space-y-6">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-primary" />
                      <h3 className="font-semibold text-slate-800">Travel Agent Rules</h3>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">

                      {/* Maximum Layover */}
                      <FormField
                        control={form.control}
                        name="maxLayoverHours"
                        render={({ field }) => (
                          <FormItem>
                            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 h-full">
                              <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4 text-muted-foreground" />
                                <div>
                                  <FormLabel className="text-sm font-medium">Maximum Layover</FormLabel>
                                  <p className="text-xs text-muted-foreground">hours allowed</p>
                                </div>
                              </div>
                              <div className="flex items-center gap-3">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8 rounded-full border-slate-200 bg-white shadow-sm"
                                  onClick={() => handleStepper("maxLayoverHours", false, 1, 48)}
                                  disabled={field.value <= 1}
                                  data-testid="btn-maxlayover-minus"
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="w-6 text-center font-semibold text-sm" data-testid="text-maxlayover">
                                  {field.value}h
                                </span>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8 rounded-full border-slate-200 bg-white shadow-sm"
                                  onClick={() => handleStepper("maxLayoverHours", true, 1, 48)}
                                  disabled={field.value >= 48}
                                  data-testid="btn-maxlayover-plus"
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </FormItem>
                        )}
                      />

                      {/* Preferred Transit Airports */}
                      <FormField
                        control={form.control}
                        name="preferredTransitAirports"
                        render={({ field }) => (
                          <FormItem className="lg:col-span-1">
                            <AirportTagInput
                              label="Preferred Transit Airports"
                              tags={field.value}
                              onChange={field.onChange}
                              testId="input-preferred-airports"
                              colorClass="bg-green-100 text-green-800 hover:bg-green-100 border-green-200"
                            />
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Avoid Transit Airports */}
                      <FormField
                        control={form.control}
                        name="avoidTransitAirports"
                        render={({ field }) => (
                          <FormItem className="lg:col-span-1">
                            <AirportTagInput
                              label="Avoid Transit Airports"
                              tags={field.value}
                              onChange={field.onChange}
                              testId="input-avoid-airports"
                              colorClass="bg-red-100 text-red-700 hover:bg-red-100 border-red-200"
                            />
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Submit */}
                  <div className="pt-2">
                    <Button
                      type="submit"
                      className="w-full h-14 text-lg rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                      size="lg"
                      data-testid="btn-submit"
                    >
                      <ScanSearch className="mr-2 h-5 w-5" />
                      Scan Date Range
                    </Button>
                  </div>

                </form>
              </Form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
